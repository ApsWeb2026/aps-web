---
date: 2026-04-08
title: Affordance
slug: affordance
type: glossary
definition: "In APS, an affordance is a viability-relevant possibility for action arising through the coupling of an organism and its environment."
inBrief: "An affordance is a viability-relevant possibility for action."
status: canonical
cluster: cognition-and-mind
revised: 2026-04-08
seeAlso:
  - environment
  - coupling
  - constraint
  - function
  - biological-agency
---

## Conventional framing

The concept of affordance originates in ecological psychology, where it refers to the actionable possibilities that the environment offers to an organism. These possibilities are not reducible to objective physical properties alone, nor to subjective perception, but are defined in relation to the organism’s capabilities. For example, a surface may afford walking for one organism but not for another, depending on its morphology and behaviour.

## APS reframing

APS retains the relational insight of the original concept but situates affordances within viability-oriented, constraint-closed organisation. An affordance is not simply an available action possibility, but a viability-relevant relation that can be incorporated into the system’s ongoing regulation of its own persistence.

This reframing emphasises that affordances are:

- Relational rather than intrinsic properties of objects  
- Dependent on the organisation and current state of the system  
- Defined by their contribution to sustaining or undermining viability  
- Realised through incorporation into constraint-closed processes  

In this sense, affordances are the bridge between environmental structure and biological function. They specify what aspects of the environment are usable within the system’s organisation and how those aspects can be taken up into ongoing activity.

Affordances therefore mediate the transition from physical constraint to biological significance. Through coupling, environmental features become available as affordances; through their integration into organisation, they become functionally effective.

## Key Point

Affordances define what is biologically usable—the relational possibilities through which viability-oriented systems sustain their organisation.


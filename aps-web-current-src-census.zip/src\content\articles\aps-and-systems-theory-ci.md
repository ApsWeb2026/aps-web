---
date: 2026-04-11
title: APS and Systems Theory — Similarities, Differences, and Limits
slug: aps-and-systems-theory
type: article
status: canonical
canonical: true
canonicalLockDate: 2026-04-11
revised: 2026-08-22
cluster: philosophy-of-biology
abstract: >
  Systems theory provides powerful tools for describing interaction, feedback,
  regulation, and dynamics in biological systems. This article compares systems
  approaches with APS by distinguishing their explanatory targets, strengths,
  and limits. APS proposes viability-oriented, constraint-closed organisation
  as a general account of living organisation and asks whether this provides
  explanatory or methodological gain when life itself is the shared target.
  Difference between the frameworks does not by itself establish complementarity,
  integration, or APS explanatory superiority.
keyPoints:
  - Systems approaches provide powerful resources for explaining and modelling interaction, feedback, regulation, dynamics, and organisation.
  - Their explanatory adequacy depends upon the biological question being addressed.
  - Some systems approaches employ analytically specified system boundaries, while others address biological organisation more substantively.
  - APS proposes viability-oriented, constraint-closed organisation as its account of living organisation.
  - Whether this account provides explanatory gain over systems approaches requires target-matched comparison rather than inference from conceptual difference.
relatedGlossaryTerms:
  - biological-agency
  - constraint-closure
  - viability
  - process
  - scale
  - normativity
  - coupling
  - mechanism
  - holism
  - organicism
relatedArticles:
  - aps-and-contemporary-theories
  - why-aps-is-not-hierarchical
  - organism-world-coupling-agency-not-control
  - explanatory-priority-is-not-ontological-priority
  - why-ai-is-not-biological-agency
  - reductionism-in-biology-an-aps-clarification
  - emergence-in-biology-an-aps-clarification
  - why-life-is-not-computation-an-aps-clarification
  - why-life-is-not-intelligence-an-aps-clarification
  - multiple-realization-and-biological-organisation
---

## Systems Theory and the Study of Organisation

Systems theory encompasses a broad set of approaches that model phenomena in terms of interacting components, feedback loops, and dynamic behaviour. In biology, these approaches have been central to moving beyond strictly reductionist explanations.

Rather than analysing isolated parts, systems approaches examine how interactions among components produce organised behaviour over time. Concepts such as feedback, regulation, stability, and emergence are central to this perspective. APS interprets such phenomena through its own account of living organisation rather than treating emergence itself as a sufficient explanation. See *[Emergence in Biology — An APS Clarification](/articles/emergence-in-biology-an-aps-clarification/)*.

These approaches have proven extremely powerful for investigating and explaining biological systems, from metabolic networks to ecological dynamics. In this respect, systems theory captures an important aspect of living organisation: biological phenomena often depend upon relations among interacting processes rather than upon isolated components considered independently.

## Points of Comparison with APS

Systems approaches and APS overlap in their attention to interaction, regulation, feedback, dynamic organisation, and relations among processes unfolding across spatial and temporal extents.

This overlap does not establish that the approaches share the same explanatory targets or organising principles. Systems theory encompasses diverse research programmes, while Systems theory encompasses diverse research programmes, while APS specifically proposes viability-oriented, constraint-closed organisation as its account of life and treats organised persistence as the explanatory problem of how living organisation maintains and re-establishes continuity through change.

Agency, Process, and Scale are complementary analytic projections within the APS Explanatory Grammar rather than co-constitutive components or dimensions of biological reality. Systems concepts such as feedback, coupling, and dynamic stability may therefore provide important points of comparison with APS without being incorporated into APS or interpreted as expressions of it.

The relationship between systems approaches and APS must consequently be assessed in relation to the question being addressed. Similarity, difference, overlap, complementarity, independence, or explanatory gain are possible comparative outcomes rather than assumptions.

[[box:how-aps-relates-to-other-theoretical-frameworks]]

## Systems Description and the Question of Living Organisation

Systems theory encompasses approaches with different explanatory aims. Many formal systems methods can describe interaction, feedback, stability, and dynamic behaviour without themselves specifying what distinguishes living organisation from other organised systems. This is not necessarily a deficiency: such methods may be designed to address different explanatory targets.

Likewise, system boundaries may sometimes be specified for purposes of modelling and analysis. Other systems and organisational approaches treat biological boundaries more substantively. It would therefore be misleading to attribute a single account of boundaries or normativity to systems theory as a whole.

Many systems-theoretic tools can be applied across domains including:

- living organisms  
- mechanical devices  
- economic systems  
- climate dynamics  

Such formal tools can be applied across these cases without necessarily distinguishing them in terms of their mode of organisation. This also helps explain why similar functional patterns may be realised across very different material systems without thereby erasing the distinction between biological and non-biological organisation. See *[Multiple Realization and Biological Organisation](/articles/multiple-realization-and-biological-organisation/)*.

## APS and the Question of Biological Organisation

APS makes living organisation itself an explicit explanatory target by proposing viability-oriented, constraint-closed organisation as its general account of living organisation.

The canonical APS formulation is:

> **Life is viability-oriented, constraint-closed organisation.**

This is the substantive biological account proposed by APS. Its canonical
status within APS does not by itself establish its comparative superiority
over alternative accounts of living organisation.

In APS, living systems are not characterised by complexity, feedback, or
dynamic behaviour alone. Their organisation is viability-oriented: activity
is organised in relation to maintaining and re-establishing the conditions
required for persistence.

This establishes a point of comparison with systems approaches that describe
interaction, feedback, stability, or dynamics without making viability-relative
living organisation their explicit explanatory target. Such approaches may
provide adequate explanations for the questions they address; APS asks the
different question of how organised activity bears upon the persistence of
the living system itself.

Within APS, **biological normativity is viability-relative asymmetry**: states, processes, and outcomes differ in their consequences for viable organisation. Biological Evaluation is the process through which agency generates significance in relation to viability-relevant differences.

Whether this APS account provides explanatory gain over systems approaches
when living organisation itself is the shared explanatory target remains a
matter for target-matched comparison. The difference in explanatory focus
does not establish that systems approaches are incomplete or that APS provides
the preferred explanation.

## System Boundaries and Organisational Closure

A central difference concerns how system boundaries are understood.

In some systems approaches, boundaries are specified for analytical or modelling purposes, so the system under investigation is partly determined by the explanatory task and modelling framework. Other systems and organisational approaches attribute greater biological significance to system boundaries.

APS proposes that biologically relevant boundaries should be investigated in
relation to constraint-closed organisation rather than treated solely as
observer-selected modelling boundaries. On this account, boundaries are
materially realised and maintained through organised biological activity.

This provides a substantive APS claim about living organisation. Whether it
improves upon alternative systems or organisational accounts of biological
boundaries requires comparative and biological assessment.

Within APS, biological boundaries are therefore investigated as materially realised features of living organisation whose maintenance may itself depend upon organised biological activity. This differs from cases in which a boundary is specified primarily for modelling or analytical purposes, without implying that systems approaches generally treat biological boundaries as externally imposed.

## Agency and the Distinction Between Living and Non-Living Systems

Formal systems descriptions can often be applied to both living and non-living
systems without requiring a criterion that distinguishes the two. APS makes
that distinction an explicit explanatory concern.

APS proposes biological agency as part of its account of this distinction. **Biological agency is viability-oriented organisational activity**: the activity through which living organisation is enacted and sustained under conditions relevant to its viability.

This distinguishes the APS account of biological agency from cases in which:

- functions are externally assigned rather than generated through viability-relative organisation;
- organised dynamics occur without satisfying the conditions APS associates with viability-oriented, constraint-closed self-maintenance.

In APS terms, agency is not an additional feature layered onto living organisation. Biological agency is viability-oriented organisational activity: the present-tense activity through which living organisation is enacted and sustained.

### Systems, Organisation, and the Appearance of Cognition

Because systems theory can describe complex, adaptive, and dynamically stable
behaviour, it can be used to model systems that appear intelligent or
cognitively organised, including artificial, computational, and social systems.

From an APS perspective, this descriptive power does not by itself establish
cognition. Cognition is not defined by behavioural complexity, feedback,
optimisation, or dynamical sophistication alone.

APS distinguishes biological organisation from adaptive systems in general
through its proposed account of viability-oriented, constraint-closed
organisation. Artificial, computational, cybernetic, and other non-biological
systems may exhibit feedback, regulation, optimisation, distributed
coordination, and complex adaptive behaviour without thereby satisfying the
conditions APS associates with biological agency or cognition.

APS therefore does not infer cognition from behavioural complexity, feedback,
optimisation, or dynamical sophistication alone. Within APS, cognition requires
a more specific organisation of biological significance across time. Whether
particular systems satisfy the relevant conditions must therefore be assessed
rather than inferred from systems complexity alone.

For further discussion, see *[Why AI Is Not Biological Agency](/articles/why-ai-is-not-biological-agency/)*
and *[Why Life Is Not Intelligence](/articles/why-life-is-not-intelligence-an-aps-clarification/)*.

## Comparing Systems Theory and APS

Systems approaches provide powerful resources for investigating interaction,
feedback, regulation, dynamical trajectories, network organisation, and other
features of biological systems.

APS addresses a particular explanatory target: living organisation and the
activity through which organised persistence is maintained despite change. It
proposes viability-oriented, constraint-closed organisation as its general
account of that target.

These differences do not establish that systems theory is merely descriptive,
that APS supplies a missing explanatory layer, or that systems approaches must
be integrated into APS. Nor does the broader applicability of systems methods
establish their superiority over APS when living organisation itself is the
question being addressed.

The appropriate relationship depends upon the explanatory target. For some
questions, systems analysis may be sufficient and preferable. Where living
organisation itself is the target, APS may provide additional explanatory or
methodological resources. Whether it does so must be established through
target-matched comparison with the strongest relevant alternatives.

Systems theory and APS should therefore be compared rather than hierarchically
nested. Complementarity, integration, overlap, independence, redundancy, or
comparative explanatory gain remain possible outcomes of that comparison.

## Key Point

Systems approaches provide powerful explanations of interaction, feedback, regulation, dynamics, and network organisation. APS proposes viability-oriented, constraint-closed organisation as its account of living organisation. Neither conceptual difference nor APS's explanatory architecture establishes comparative superiority. Where systems approaches and APS address the same target, explanatory preference requires target-matched comparison against the strongest relevant alternatives.

## Explanatory Architecture
### Central Question

How do systems-theoretical approaches and APS converge and differ in their explanations of organisation, interaction, regulation, dynamics, and living persistence, and what comparative significance follows when they address the same explanatory target?

### Architectural Role

This comparative article examines APS alongside the heterogeneous family of systems-theoretical approaches used in biology. It distinguishes shared attention to interaction, regulation, feedback, dynamics, boundaries, and organisation from differences in explanatory target, conceptual architecture, and biological specificity. Its purpose is comparative rather than adjudicative: difference between APS and systems approaches does not establish explanatory gain, and comparative preference requires target-matched assessment.

### Preceding Explanatory Dependencies

These concepts and articles establish the explanatory resources presupposed by this article. They identify dependencies within the APS corpus rather than chronology, hierarchy, or levels of organisation.

- What Is APS?
- APS and Contemporary Theories
- Organised Persistence
- Biological Agency
- Constraint Closure
- Viability
- Biological Organisation
- Emergence in Biology — An APS Clarification
Multiple Realization and Biological Organisation
Subsequent Explanatory Developments

### The distinctions established here are developed or applied in:

- Organism–World Coupling: Agency, Not Control
- Explanatory Priority Is Not Ontological Priority
- Why AI Is Not Biological Agency
- Why Life Is Not Computation
- Why Life Is Not Intelligence
- Why APS Reframes Biology
- Related Explanatory Questions
- Which systems-theoretical approaches address living organisation itself rather than more general system dynamics?
- When do systems theory and APS address genuinely matched explanatory targets?
- How should modelling boundaries be distinguished from biologically maintained boundaries?
- How do feedback, regulation, constraint closure, and viability relate across the two approaches?
- Under what conditions might systems analysis and APS prove complementary, overlapping, independent, redundant, competing, or differentially explanatory?
- What evidence would be required to establish explanatory gain favouring either APS or a systems-theoretical alternative?

### Position Within APS

This article forms part of the APS Comparative Biology series. It compares APS with a diverse family of systems approaches without treating systems theory as a single homogeneous framework or assuming that APS's biological specificity provides automatic explanatory advantage. It preserves APS's substantive account of **life as viability-oriented, constraint-closed organisation** and its treatment of **organised persistence as the explanatory problem of continuity through change**, while requiring comparative claims to be assessed against the strongest systems-theoretical alternative addressing the same question.
---
date: 2026-04-05
title: "The One-Page Framework Map"
slug: "the-one-page-framework-map"
type: article
abstract: "This article presents a one-page map of the APS framework, showing how its core concepts, explanatory relations, and research pathways fit together in a single orienting structure."
status: canonical
revised: 2026-04-05
cluster: methodology-and-explanation
keyPoints:
  - "The framework map provides a compact overview of APS as an integrated system."
  - "It clarifies how the core concepts and research streams relate to one another."
  - "APS is best understood as a structured explanatory framework rather than a list of claims."
relatedGlossaryTerms:
  - biological-agency
  - process
  - scale
relatedArticles: []
researchStreams: []
references: []
---

## The Agency-Process-Scale Architecture of Life

### 1. Definition of Life (APS)

Life is the organisation of biological agency - the viability-oriented, self-evaluating activity through which a system sustains its own persistence.

Living systems differ from most physical systems in a crucial way: their activity is organised around maintaining the conditions required for their continued existence.

### 2. The APS Triad

APS interprets biological biological organisation through three mutually dependent dimensions:

| Dimension | Meaning |
| --- | --- |
| **Agency** | Viability-oriented regulation of conditions for persistence |
| **Process** | Dynamic flows of matter, energy, and interaction |
| **Scale** | Spatial and temporal extent across which processes unfold |

These are not independent components but three perspectives on the same organisational phenomenon. Living systems are agents whose persistence is enacted through processes across scale.

### 3. Minimal APS Explanatory Grammar

The APS framework clarifies how key biological concepts relate to one another:

**Agency - Normativity - Function - Adaptation - evolution**

| Concept | Meaning |
| --- | --- |
| **Agency** | Viability-oriented biological organisation |
| **Normativity** | Distinction between viable and non-viable states |
| **Function** | Contribution to sustaining viability |
| **Adaptation** | Historically stabilised viability-supporting traits |
| **evolution** | Long-term transformation of these traits |

This chain represents the minimal grammar of biological explanation.

### 4. Organisational Architecture of evolution

APS clarifies the organisational conditions required for evolutionary processes:

**Viability-oriented biological agency - Organised persistence - Reproduction - Natural selection - evolution**

- Agency sustains viability
- Persistence maintains biological organisation through time
- Reproduction extends persistence across generations
- Selection filters variants
- evolution transforms biological organisation historically

evolution therefore operates on systems already organised around their own persistence.

### 5. The APS Synthesis Diagram

The APS synthesis can be understood as three integrated layers:

1. **APS triad**
   - Agency
   - Process
   - Scale

2. **Organised persistence**
   - Persistence
   - Reproduction

3. **Evolutionary transformation**
   - Selection
   - evolution

In this framework, biological agency is enacted through process across scale; organised persistence makes reproduction possible; and reproduction allows selection and evolution to transform viability-oriented biological organisation historically.

### 6. Domains Integrated by APS

APS connects multiple domains of biological research:

- **Molecular biology** - Processes sustaining cellular viability  
- **Physiology** - Regulation of organismal persistence  
- **Ecology** - Organism and environment interactions affecting viability  
- **evolution** - Historical transformation of persistence strategies  

Rather than separate explanatory frameworks, these become different perspectives on the same organisational phenomenon.

### 7. Historical Position of APS

Biological theory has progressively incorporated phenomena once treated as metaphysical:

- **Aristotle** - purpose in living systems
- **Scientific revolution** - mechanistic biology
- **Darwin** - historical explanation of adaptation
- **Systems biology** - organised regulation
- **APS** - naturalised biological biological agency

APS continues this trajectory by providing a naturalised account of biological agency and normativity in biology.

### 8. The Central Insight

Life is organised biological agency enacted through process across scale.

evolution is the historical transformation of viability-oriented biological organisation.

### 9. Why APS Matters

APS provides:

- a definition of life grounded in biological organisation
- a unified explanatory grammar for biology
- a clear relationship between physiology and evolution
- a naturalised account of biological normativity and function

**Core Definition.**

In APS, life is viability-oriented biological agency: the organised activity through which living systems sustain their own persistence. evolution is the historical transformation of that biological organisation across generations. Biology is therefore the study of how viability-oriented biological organisation is sustained in the present and transformed through evolutionary time.

## Reading APS as a System

APS concepts should not be interpreted in isolation. aTerms such as biological agency, process, and normativity are defined in relation to one another within a constraint-closed conceptual structure.

For an explanation of how APS definitions form an organised system, see:
- APS as an Organised Conceptual System - Why Definitions Form a System




